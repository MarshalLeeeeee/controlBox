#include "Constant.h"

const int Constant::width = 1280;
const int Constant::height = 960;
const float Constant::dt = 0.005;
const float Constant::bound = 20.0;